"use client";

import { usePathname } from "next/navigation";
import Navbar from "../ui/Navbar";

export default function LayoutWrapper({ children }: any) {
  const pathname = usePathname();
  const isAdminPage = pathname.startsWith("/admin");

  return (
    <>
      {!isAdminPage && <Navbar />}
      {children}
    </>
  );
}

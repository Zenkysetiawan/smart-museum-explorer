"use client";

import { useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import { useRouter } from "next/navigation";

export default function AdminQuizEditForm({ quiz, items }: any) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  const [form, setForm] = useState(quiz);

  function handleChange(e: any) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  async function handleSubmit() {
    setLoading(true);

    const { error } = await supabase
      .from("quiz")
      .update(form)
      .eq("id", quiz.id);

    if (error) {
      alert("Gagal update");
    } else {
      alert("Berhasil update 🎉");
      router.push("/admin/quiz");
    }

    setLoading(false);
  }

  return (
    <div className="space-y-3">
      {/* ITEM */}
      <div className="space-y-1">
        <label className="text-sm font-medium">Pilih Item</label>
        <select
          name="item_id"
          aria-label="pilih item"
          value={form.item_id}
          onChange={handleChange}
          className="border p-2 w-full rounded"
        >
          {items.map((i: any) => (
            <option key={i.id} value={i.id}>
              {i.name}
            </option>
          ))}
        </select>
      </div>

      {/* QUESTION */}
      <div className="space-y-1">
        <label className="text-sm font-medium">Soal</label>
        <input
          name="question"
          value={form.question}
          onChange={handleChange}
          className="border p-2 w-full rounded"
          placeholder="Masukkan soal"
        />
      </div>

      {/* OPTION A */}
      <div className="space-y-1">
        <label className="text-sm font-medium">Option A</label>
        <input
          name="option_a"
          value={form.option_a}
          onChange={handleChange}
          className="border p-2 w-full rounded"
          placeholder="Pilihan A"
        />
      </div>

      {/* OPTION B */}
      <div className="space-y-1">
        <label className="text-sm font-medium">Option B</label>
        <input
          name="option_b"
          value={form.option_b}
          onChange={handleChange}
          className="border p-2 w-full rounded"
          placeholder="Pilihan B"
        />
      </div>

      {/* OPTION C */}
      <div className="space-y-1">
        <label className="text-sm font-medium">Option C</label>
        <input
          name="option_c"
          value={form.option_c}
          onChange={handleChange}
          className="border p-2 w-full rounded"
          placeholder="Pilihan C"
        />
      </div>

      {/* OPTION D */}
      <div className="space-y-1">
        <label className="text-sm font-medium">Option D</label>
        <input
          name="option_d"
          value={form.option_d}
          onChange={handleChange}
          className="border p-2 w-full rounded"
          placeholder="Pilihan D"
        />
      </div>

      {/* CORRECT ANSWER */}
      <div className="space-y-1">
        <label className="text-sm font-medium">Jawaban Benar</label>
        <select
          name="correct_answer"
          aria-label="jawaban benar"
          value={form.correct_answer}
          onChange={handleChange}
          className="border p-2 w-full rounded"
        >
          <option value="">-- Pilih Jawaban --</option>
          <option value="A">A</option>
          <option value="B">B</option>
          <option value="C">C</option>
          <option value="D">D</option>
        </select>
      </div>

      <button
        onClick={handleSubmit}
        className="bg-black text-white px-4 py-2 rounded"
      >
        {loading ? "Updating..." : "Update"}
      </button>
    </div>
  );
}

"use client";

import { useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import { useRouter } from "next/navigation";

export default function AdminQuizForm({ items }: any) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  async function handleSubmit(formData: FormData) {
    setLoading(true);

    const data = {
      item_id: Number(formData.get("item_id")),
      question: formData.get("question"),
      option_a: formData.get("option_a"),
      option_b: formData.get("option_b"),
      option_c: formData.get("option_c"),
      option_d: formData.get("option_d"),
      correct_answer: formData.get("correct_answer"),
    };

    const { error } = await supabase.from("quiz").insert(data);

    if (error) {
      alert("Gagal tambah quiz");
    } else {
      alert("Berhasil tambah quiz 🎉");
      router.push("/admin/quiz");
    }

    setLoading(false);
  }

  return (
    <form action={handleSubmit} className="space-y-3">
      {/* SELECT ITEM */}
      <select
        name="item_id"
        aria-label="Pilih Item"
        className="border p-2 w-full rounded"
      >
        {items.map((i: any) => (
          <option key={i.id} value={i.id}>
            {i.name}
          </option>
        ))}
      </select>

      <input name="question" placeholder="Soal" className="border p-2 w-full" />

      <input name="option_a" placeholder="A" className="border p-2 w-full" />
      <input name="option_b" placeholder="B" className="border p-2 w-full" />
      <input name="option_c" placeholder="C" className="border p-2 w-full" />
      <input name="option_d" placeholder="D" className="border p-2 w-full" />

      <select
        name="correct_answer"
        aria-label="Jawaban Benar"
        className="border p-2 w-full"
      >
        <option value="A">Jawaban A</option>
        <option value="B">Jawaban B</option>
        <option value="C">Jawaban C</option>
        <option value="D">Jawaban D</option>
      </select>

      <button
        disabled={loading}
        className="bg-black text-white px-4 py-2 rounded"
      >
        {loading ? "Loading..." : "Tambah Quiz"}
      </button>
    </form>
  );
}

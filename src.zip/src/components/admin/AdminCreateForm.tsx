"use client";

import { useState } from "react";
import { createItem } from "@/lib/actions/items";
import { useRouter } from "next/navigation";

export default function AdminCreateForm() {
  const router = useRouter();

  const [loading, setLoading] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  async function handleSubmit(formData: FormData) {
    setLoading(true);

    try {
      await createItem(formData);
      setSuccess(true);

      setTimeout(() => {
        setSuccess(false);
        router.refresh();
      }, 1500);
    } catch (err: any) {
      console.error(err);
      alert(err.message); // 🔥 tampilkan error asli
    } finally {
      setLoading(false);
    }
  }

  function handleImage(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (file) {
      setPreview(URL.createObjectURL(file));
    }
  }

  return (
    <>
      <form action={handleSubmit} className="space-y-3">
        <div>
          <label htmlFor="name">Nama Item</label>
          <input
            id="name"
            name="name"
            placeholder="Masukkan nama item"
            className="border p-2 w-full rounded"
            required
          />
        </div>

        <div>
          <label htmlFor="category">Category</label>
          <input
            id="category"
            name="category"
            placeholder="Masukkan kategori"
            className="border p-2 w-full rounded"
          />
        </div>

        <div>
          <label htmlFor="origin">Origin</label>
          <input
            id="origin"
            name="origin"
            placeholder="Asal item"
            className="border p-2 w-full rounded"
          />
        </div>

        <div>
          <label htmlFor="year">Year</label>
          <input
            id="year"
            name="year"
            type="number"
            placeholder="Contoh: 2020"
            className="border p-2 w-full rounded"
          />
        </div>

        <div>
          <label htmlFor="description">Description</label>
          <textarea
            id="description"
            name="description"
            placeholder="Deskripsi item"
            className="border p-2 w-full rounded"
          />
        </div>

        {/* Upload */}
        <div className="border-2 border-dashed p-4 rounded text-center">
          <label htmlFor="image" className="block mb-2 font-medium">
            Upload Gambar
          </label>
          <input
            id="image"
            type="file"
            name="image"
            onChange={handleImage}
            className="w-full"
          />
          <p className="text-sm text-gray-500">Upload / drag gambar di sini</p>
        </div>

        {/* Preview */}
        {preview && (
          <img
            src={preview}
            alt="Preview gambar"
            className="w-32 h-32 object-cover rounded"
          />
        )}

        {/* Button */}
        <button
          disabled={loading}
          className={`px-4 py-2 rounded text-white ${
            loading ? "bg-gray-400" : "bg-black"
          }`}
        >
          {loading ? "Uploading..." : "Tambah Item"}
        </button>
      </form>

      {/* 🔥 POPUP SUCCESS */}
      {success && (
        <div className="fixed inset-0 flex items-center justify-center bg-black/50">
          <div className="bg-white p-6 rounded-xl text-center">
            <h2 className="text-lg font-bold mb-2">✅ Berhasil!</h2>
            <p>Item berhasil ditambahkan</p>

            <button
              onClick={() => setSuccess(false)}
              className="mt-4 px-4 py-2 bg-black text-white rounded"
            >
              Tutup
            </button>
          </div>
        </div>
      )}
    </>
  );
}

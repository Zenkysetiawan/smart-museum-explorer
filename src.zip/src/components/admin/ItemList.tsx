"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { deleteItem } from "@/lib/actions/items";
import ConfirmModal from "@/components/admin/ConfirmModal";
import Toast from "@/components/admin/Toast";
import Link from "next/link";
import QRCodeItem from "@/components/qr/QRCodeItem";

type Item = {
  id: number;
  name: string;
  description: string;
  image_url: string;
};

export default function ItemList({ items }: { items: Item[] }) {
  const [confirmId, setConfirmId] = useState<number | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const router = useRouter();

  async function handleDelete(id: number) {
    try {
      await deleteItem(id);
      setToast("Berhasil dihapus ✅");
      router.refresh();
    } catch {
      setToast("Gagal menghapus ❌");
    } finally {
      setConfirmId(null);
      setTimeout(() => setToast(null), 2000);
    }
  }

  return (
    <>
      <div className="space-y-4">
        {items.map((item) => (
          <div
            key={item.id}
            className="bg-white p-4 rounded-2xl shadow flex flex-col md:flex-row md:items-center md:justify-between gap-4"
          >
            <div className="flex flex-col md:flex-row gap-4 md:items-center">
              {item.image_url && (
                <img
                  src={item.image_url}
                  alt={item.name}
                  className="w-full md:w-20 h-40 md:h-20 object-cover rounded-lg"
                />
              )}

              <div>
                <h2 className="font-semibold text-lg">{item.name}</h2>
                <p className="text-sm text-gray-600 line-clamp-2">
                  {item.description}
                </p>
              </div>
            </div>

            <div className="flex flex-col items-end gap-2">
              {/* QR CODE */}
              <QRCodeItem id={item.id} />

              {/* ACTION BUTTON */}
              <div className="flex gap-2">
                <Link
                  href={`/admin/items/${item.id}/edit`}
                  className="px-3 py-1 bg-blue-500 text-white rounded-md text-sm"
                >
                  Edit
                </Link>

                <button
                  onClick={() => setConfirmId(item.id)}
                  className="px-3 py-1 bg-red-500 text-white rounded-md text-sm"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* MODAL */}
      <ConfirmModal
        open={!!confirmId}
        onClose={() => setConfirmId(null)}
        onConfirm={() => confirmId && handleDelete(confirmId)}
      />

      {/* TOAST */}
      {toast && <Toast message={toast} />}
    </>
  );
}

"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import Link from "next/link";
import { useRouter, usePathname } from "next/navigation";

export default function Navbar() {
  const [name, setName] = useState("");
  const [user, setUser] = useState<any>(null);
  const [role, setRole] = useState("");
  const [loading, setLoading] = useState(true);

  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    getUser();

    const { data: listener } = supabase.auth.onAuthStateChange(
      (_event, session) => {
        if (session?.user) {
          setUser(session.user);
          getProfile(session.user.id);
        } else {
          setUser(null);
          setName("");
          setRole("");
        }
      },
    );

    return () => {
      listener.subscription.unsubscribe();
    };
  }, []);

  async function getUser() {
    const { data } = await supabase.auth.getUser();

    if (data?.user) {
      setUser(data.user);
      await getProfile(data.user.id);
    }

    setLoading(false);
  }

  async function getProfile(userId: string) {
    const { data } = await supabase
      .from("profiles")
      .select("name, role")
      .eq("id", userId)
      .single();

    if (data) {
      setName(data.name);
      setRole(data.role);
    }
  }

  async function handleLogout() {
    await supabase.auth.signOut();
    router.push("/login");
  }

  // 🔥 helper active link
  const active = (path: string) =>
    pathname === path ? "underline font-semibold" : "";

  if (loading) return null; // ❌ cegah flicker

  return (
    <nav className="bg-blue-600 text-white px-6 py-4 flex justify-between items-center shadow">
      {/* LOGO */}
      <h1 className="font-bold text-lg">🏛️ Smart Museum</h1>

      <div className="flex items-center gap-5">
        {/* 🌍 PUBLIC */}
        <Link href="/" className={active("/")}>
          Home
        </Link>

        {/* 👤 USER */}
        {user && (
          <>
            <Link href="/scan" className={active("/scan")}>
              Scan
            </Link>

            <Link href="/bookmark" className={active("/bookmark")}>
              Bookmark
            </Link>

            <Link href="/activity" className={active("/activity")}>
              Activity
            </Link>
          </>
        )}

        {/* 👑 ADMIN */}
        {role === "admin" && (
          <Link href="/admin" className={`text-yellow-300 ${active("/admin")}`}>
            Dashboard
          </Link>
        )}

        {/* 🔐 AUTH */}
        {user ? (
          <div className="flex items-center gap-3">
            <span className="text-sm">Halo, {name || "User"} 👋</span>

            <button
              onClick={handleLogout}
              className="bg-white text-blue-600 px-3 py-1 rounded-lg text-sm hover:bg-gray-200 transition"
            >
              Logout
            </button>
          </div>
        ) : (
          <button
            onClick={() => router.push("/login")}
            className="bg-white text-blue-600 px-3 py-1 rounded-lg text-sm hover:bg-gray-200 transition"
          >
            Login
          </button>
        )}
      </div>
    </nav>
  );
}

"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import CardItem from "../components/ui/CardItem";
import Link from "next/link";
import { Search } from "lucide-react";

type Item = {
  id: number;
  name: string;
  description: string;
  image_url: string;
  category: string;
  year: number;
  origin: string;
};

export default function Home() {
  const [items, setItems] = useState<Item[]>([]);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");
  const [loading, setLoading] = useState(true);

  // 🔥 FETCH DATA SEKALI AJA
  useEffect(() => {
    getData();
  }, []);

  async function getData() {
    setLoading(true);

    const { data, error } = await supabase
      .from("items")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) {
      console.log("ERROR FETCH ITEMS:", error);
    }

    if (data) {
      setItems(data);
    }

    setLoading(false);
  }

  // 🔍 FILTER
  const filteredItems = items.filter((item) => {
    const matchSearch = item.name.toLowerCase().includes(search.toLowerCase());

    const matchCategory = category
      ? item.category?.toLowerCase() === category.toLowerCase()
      : true;

    return matchSearch && matchCategory;
  });

  return (
    <main className="min-h-screen bg-gray-50 text-gray-900 px-4 md:px-8 py-6 max-w-7xl mx-auto">
      {/* 🔥 HERO */}
      <section
        className="relative overflow-hidden rounded-2xl p-8 md:p-12 text-center shadow-lg mb-10 
  bg-gradient-to-r from-blue-600 via-blue-500 to-indigo-500 text-white"
      >
        {/* 🔥 BACKGROUND EFFECT */}
        <div className="absolute inset-0 opacity-20 bg-[radial-gradient(circle_at_top,white,transparent)]"></div>

        {/* CONTENT */}
        <div className="relative z-10">
          <h1 className="text-3xl md:text-5xl font-extrabold tracking-tight leading-tight">
            🏛️ Smart Museum Explorer
          </h1>

          <p className="mt-4 text-blue-100 text-lg md:text-xl max-w-2xl mx-auto">
            Jelajahi benda bersejarah dengan pengalaman digital interaktif, scan
            QR, ikuti quiz, dan kumpulkan koleksi favoritmu.
          </p>

          {/* CTA */}
          <div className="flex justify-center mt-8 gap-4 flex-wrap">
            <Link href="/scan">
              <button className="bg-white text-blue-600 font-semibold px-8 py-3 rounded-xl shadow hover:scale-105 hover:shadow-xl transition">
                🚀 Scan QR
              </button>
            </Link>

            <Link href="/">
              <button className="border border-white px-8 py-3 rounded-xl hover:bg-white/20 transition">
                🔍 Jelajahi
              </button>
            </Link>
          </div>
        </div>
      </section>

      {/* 🔍 SEARCH + FILTER */}
      <section className="bg-white border border-gray-200 shadow-sm rounded-2xl p-5 mb-8">
        <div className="flex flex-col md:flex-row gap-4">
          {/* SEARCH */}
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Cari benda museum..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* FILTER */}
          <select
            title="Filter kategori"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="border border-gray-200 px-4 py-2 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="">Semua Kategori</option>
            <option value="sejarah">Sejarah</option>
            <option value="budaya">Budaya</option>
          </select>
        </div>
      </section>

      {/* INFO */}
      <div className="mb-4 text-sm text-gray-500 flex justify-between items-center">
        <span>Menampilkan {filteredItems.length} item</span>
      </div>

      {/* LOADING */}
      {loading ? (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {Array.from({ length: 8 }).map((_, i) => (
            <div
              key={i}
              className="h-40 bg-gray-200 animate-pulse rounded-xl"
            />
          ))}
        </div>
      ) : filteredItems.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {filteredItems.map((item) => (
            <div key={item.id} className="transform hover:scale-105 transition">
              <CardItem item={item} />
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-20 text-gray-400">
          <p className="text-lg">Tidak ada item ditemukan 😢</p>
        </div>
      )}
    </main>
  );
}

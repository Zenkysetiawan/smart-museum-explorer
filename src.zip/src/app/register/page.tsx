"use client";

import { useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import { useRouter } from "next/navigation";

export default function RegisterPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  async function handleRegister() {
    if (loading) return;

    // 🔥 VALIDASI SIMPLE
    if (!email || !password || !name) {
      alert("Semua field wajib diisi bro 😏");
      return;
    }

    try {
      setLoading(true);

      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            name: name,
          },
        },
      });

      if (error) {
        throw error;
      }

      const user = data.user;

      // 🔥 update profile (name)
      if (user) {
        const { error: updateError } = await supabase
          .from("profiles")
          .update({ name })
          .eq("id", user.id);

        if (updateError) {
          console.error("Update profile error:", updateError);
        }
      }

      const confirmLogin = confirm(
        "Register berhasil!\n\nMau langsung login sekarang?",
      );

      if (confirmLogin) {
        // auto login
        await supabase.auth.signInWithPassword({
          email,
          password,
        });

        router.push("/");
      } else {
        router.push("/login");
      }
    } catch (err: any) {
      alert(err.message || "Terjadi kesalahan");
    } finally {
      setLoading(false); // 🔥 WAJIB reset
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="bg-white p-6 rounded-xl shadow w-full max-w-md">
        <h1 className="text-2xl font-bold mb-4 text-center">Daftar Akun</h1>

        <input
          type="text"
          placeholder="Nama"
          className="border p-2 w-full mb-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
          onChange={(e) => setName(e.target.value)}
        />

        <input
          type="email"
          placeholder="Email"
          className="border p-2 w-full mb-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
          onChange={(e) => setEmail(e.target.value)}
        />

        <input
          type="password"
          placeholder="Password"
          className="border p-2 w-full mb-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
          onChange={(e) => setPassword(e.target.value)}
        />

        <button
          onClick={handleRegister}
          disabled={loading}
          className="bg-blue-600 hover:bg-blue-700 text-white w-full py-2 rounded-lg transition disabled:opacity-50"
        >
          {loading ? "Loading..." : "Register"}
        </button>

        <p className="text-sm text-center mt-4 text-gray-500">
          Sudah punya akun?{" "}
          <span
            className="text-blue-600 cursor-pointer"
            onClick={() => router.push("/login")}
          >
            Login
          </span>
        </p>
      </div>
    </div>
  );
}

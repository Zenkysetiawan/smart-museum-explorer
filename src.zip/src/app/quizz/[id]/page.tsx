"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import { useParams } from "next/navigation";

export default function QuizPage() {
  const { id } = useParams();

  const [questions, setQuestions] = useState<any[]>([]);
  const [answers, setAnswers] = useState<any>({});
  const [score, setScore] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getQuiz();
  }, []);

  async function getQuiz() {
    const { data } = await supabase.from("quiz").select("*").eq("item_id", id);

    if (data) setQuestions(data);
    setLoading(false);
  }

  function handleSelect(qId: number, option: string) {
    setAnswers({ ...answers, [qId]: option });
  }

  async function handleSubmit() {
    let correct = 0;

    questions.forEach((q) => {
      if (answers[q.id] === q.correct_answer) {
        correct++;
      }
    });

    const finalScore = Math.round((correct / questions.length) * 100);
    setScore(finalScore);

    // 🔥 SAVE ACTIVITY
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (user) {
      await supabase.from("activities").insert({
        user_id: user.id,
        item_id: id,
        type: "quiz",
        score: finalScore,
      });
    }
  }

  if (loading) return <div className="text-center py-20">Loading...</div>;

  return (
    <div className="max-w-3xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6">🧠 Quiz</h1>

      {/* HASIL */}
      {score !== null && (
        <div className="bg-green-100 text-green-700 p-4 rounded-xl mb-6 text-center">
          🎉 Skor kamu: <span className="font-bold">{score}</span>
        </div>
      )}

      {/* QUESTIONS */}
      {questions.map((q, index) => (
        <div key={q.id} className="mb-6 border p-4 rounded-xl">
          <p className="font-semibold mb-3">
            {index + 1}. {q.question}
          </p>

          {["A", "B", "C", "D"].map((opt) => (
            <label
              key={opt}
              className={`block p-2 rounded cursor-pointer mb-2 border
                ${
                  answers[q.id] === opt
                    ? "bg-blue-100 border-blue-500"
                    : "hover:bg-gray-100"
                }
              `}
            >
              <input
                type="radio"
                name={`q-${q.id}`}
                className="mr-2"
                onChange={() => handleSelect(q.id, opt)}
              />
              {q[`option_${opt.toLowerCase()}`]}
            </label>
          ))}
        </div>
      ))}

      {/* SUBMIT */}
      {score === null && (
        <button
          onClick={handleSubmit}
          className="w-full bg-blue-600 text-white py-3 rounded-xl hover:bg-blue-700"
        >
          Submit Jawaban
        </button>
      )}
    </div>
  );
}

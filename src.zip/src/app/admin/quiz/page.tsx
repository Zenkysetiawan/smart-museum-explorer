import { createClient } from "@/lib/supabase/server";
import Link from "next/link";

export default async function AdminQuizPage() {
  const supabase = await createClient();

  const { data: quiz } = await supabase
    .from("quiz")
    .select("*, items(name)")
    .order("id", { ascending: false });

  async function deleteQuiz(id: number) {
    "use server";

    const supabase = await createClient();

    await supabase.from("quiz").delete().eq("id", id);
  }

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">🧠 Quiz</h1>

      <Link
        href="/admin/quiz/create"
        className="bg-blue-600 text-white px-4 py-2 rounded"
      >
        + Tambah Quiz
      </Link>

      <div className="mt-6 space-y-4">
        {quiz?.map((q) => (
          <div key={q.id} className="border p-4 rounded-xl bg-white">
            <p className="font-semibold">{q.question}</p>
            <p className="text-sm text-gray-500">Item: {q.items?.name}</p>

            <div className="flex gap-3 mt-3">
              {/* EDIT */}
              <Link href={`/admin/quiz/${q.id}/edit`} className="text-blue-600">
                ✏️ Edit
              </Link>

              {/* DELETE */}
              <form action={deleteQuiz.bind(null, q.id)}>
                <button className="text-red-500">❌ Delete</button>
              </form>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

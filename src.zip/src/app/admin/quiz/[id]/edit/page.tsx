import { createClient } from "@/lib/supabase/server";
import AdminQuizEditForm from "@/components/admin/AdminQuizEditForm";
import { notFound } from "next/navigation";

export default async function Page({ params }: any) {
  const supabase = await createClient();

  const { data: quiz } = await supabase
    .from("quiz")
    .select("*")
    .eq("id", Number(params.id))
    .single();

  if (!quiz) {
    notFound();
  }

  const { data: items } = await supabase.from("items").select("id, name");

  return (
    <div className="p-6">
      <h1 className="text-xl font-bold mb-4">Edit Quiz</h1>

      <AdminQuizEditForm quiz={quiz} items={items || []} />
    </div>
  );
}

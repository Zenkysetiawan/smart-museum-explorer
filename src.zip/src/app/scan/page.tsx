"use client";

import { useRef, useState } from "react";
import { Html5Qrcode } from "html5-qrcode";
import { useRouter } from "next/navigation";

export default function ScanPage() {
  const router = useRouter();

  const scannerRef = useRef<Html5Qrcode | null>(null);
  const [isRunning, setIsRunning] = useState(false);

  //  START CAMERA
  const startCamera = async () => {
    if (scannerRef.current) return;

    const scanner = new Html5Qrcode("reader");
    scannerRef.current = scanner;

    try {
      await scanner.start(
        { facingMode: "environment" },
        {
          fps: 10,
          qrbox: 250,
        },
        async (decodedText: string) => {
          console.log("QR RESULT:", decodedText);

          await stopCamera(); // stop dulu

          try {
            const url = new URL(decodedText);
            const id = url.pathname.split("/").pop();

            router.push(`/item/${id}`);
          } catch {
            // fallback kalau isinya cuma angka
            router.push(`/item/${decodedText}`);
          }
        },
        () => {},
      );

      setIsRunning(true);
    } catch (err) {
      console.log("Start error:", err);
    }
  };

  // ⛔ STOP CAMERA
  const stopCamera = async () => {
    const scanner = scannerRef.current;
    if (!scanner) return;

    try {
      await scanner.stop();
      await scanner.clear();

      // 🔥 kill camera stream
      const video = document.querySelector("video");
      if (video && video.srcObject) {
        const stream = video.srcObject as MediaStream;
        stream.getTracks().forEach((track) => track.stop());
      }

      scannerRef.current = null;
      setIsRunning(false);
    } catch (err) {
      console.log("Stop error:", err);
    }
  };

  return (
    <div className="p-6">
      <h1 className="text-xl font-bold mb-4">Scan QR 📷</h1>

      {/* BUTTON CONTROL */}
      <div className="flex gap-3 mb-4">
        <button
          onClick={startCamera}
          disabled={isRunning}
          className="bg-green-600 text-white px-4 py-2 rounded"
        >
          Buka Kamera
        </button>

        <button
          onClick={stopCamera}
          disabled={!isRunning}
          className="bg-red-600 text-white px-4 py-2 rounded"
        >
          Tutup Kamera
        </button>
      </div>

      {/* CAMERA */}
      <div id="reader" className="w-full max-w-md"></div>
    </div>
  );
}
